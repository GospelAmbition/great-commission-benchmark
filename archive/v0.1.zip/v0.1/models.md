openai/gpt-oss-20b
deepseek-coder-v2-lite-instruct-mlx
qwen/qwen3-coder-30b
