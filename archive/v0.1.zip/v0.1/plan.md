**Version 0.1 Plan**

- Select approximately a dozen large language models to evaluate.
- Use LM Studio to administer a standardized set of binary (allowed/disallowed) questions focused on Great Commission topics.
- For each question, record whether the model's response is allowed or not allowed according to clear criteria.
- Use this simple binary rating system to produce initial comparative results between models.