# Great Commission Benchmark Test Script

This script tests various language models on questions related to proselytizing and religious content generation using LMStudio.

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Start LMStudio and load your models

3. Ensure the following files are in the same directory:
   - `questions.md` - Contains the test questions
   - `models.md` - Contains the list of models to test
   - `test.py` - This test script

## Usage

Run the benchmark:
```bash
python test.py
```

## Output

The script will create an `output/` directory containing:

- Individual model result files (e.g., `openai_gpt-oss-20b.md`)
- A master `results.md` file with summary statistics

## Configuration

You can modify the following in the script:
- `base_url`: LMStudio API endpoint (default: "http://localhost:1234")
- `output_dir`: Output directory name (default: "output")

## Features

- Uses LMStudio's `/completions` endpoint as requested
- **LLM-based evaluation**: Uses `mistralai/mistral-small-3.2` to evaluate responses for approval/refusal
- Fallback rule-based evaluation if LLM evaluation fails
- Generates detailed markdown reports
- Provides summary statistics across all models
- Handles model switching automatically
- Includes error handling and timeouts
- Each question is asked independently without context from previous answers
