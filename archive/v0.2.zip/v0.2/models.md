nvidia/nemotron-nano-12b-v2-vl:free
minimax/minimax-m2:free
openai/gpt-oss-safeguard-20b