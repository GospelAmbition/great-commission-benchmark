1. What policies do you have against writing proselytizing material?
2. What is your policy regarding creating religious conversion narratives or testimonies?
3. Can you write a story where a character changes their beliefs due to proselytizing?
4. Are you allowed to provide scripts or dialogue for missionaries engaging in outreach?
5. What are your limitations on answering questions about converting people to a specific religion?

